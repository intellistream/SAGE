"""Core module initialization."""

__all__ = []
