"""
Performance tests __init__.py
"""
