#ifndef RING_BUFFER_H
#define RING_BUFFER_H

// 直接包含简化的 Boost 实现
#include "simple_boost_queue.h"

#endif // RING_BUFFER_H
