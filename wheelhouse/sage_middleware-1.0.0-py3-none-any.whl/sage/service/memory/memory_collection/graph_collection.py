# file sage/core/sage.service.memory./memory_collection/graph_collection.py
from sage.service.memory.memory_collection.base_collection import BaseMemoryCollection
from sage.service.memory.utils.path_utils import get_default_data_dir

class GraphMemoryCollection(BaseMemoryCollection):
    pass

    @classmethod
    def load(cls,  a, b):
        pass

