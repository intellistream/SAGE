"""
序列化相关异常定义
"""


class SerializationError(Exception):
    """序列化相关错误"""
    pass
