"""
SAGE Plugins Module
===================

插件系统模块，提供扩展和插件管理功能。
"""

# 版本信息
__version__ = "1.0.0"
__author__ = "IntelliStream Team"

# 公开的API
__all__ = [
    # 将由子模块填充
]
